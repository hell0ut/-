#ВАРИАНТ 6 ДЕМАРЕЦЬКИЙ
import time
import os

#region lab1

def lab1():
    print('decompostion:',get_muliples(int(input("Enter int number: "))))
    print('num of negative numbers:',num_of_minimal(list(map(float,input("enter numbers divided by space: ").split())),0))


#region task1
def div2(num,multiples):
    if num%2==0:
        num/=2
        multiples.append(str(2))
        num=div2(num,multiples) or num
        return int(num)

def div3(num,multiples):
    if num%3==0:
        num/=3
        multiples.append(str(3))
        num=div3(num,multiples) or num
        return int(num)

def div5(num,multiples):
    if num%5==0:
        num/=5
        multiples.append(str(5))
        num=div5(num,multiples) or num
        return int(num)

def div7(num,multiples):
    if num%7==0:
        num/=7
        multiples.append(str(7))
        num=div7(num,multiples) or num
        return int(num)

def get_muliples(num):
    multiples=[]
    if num!=1:
        num=div2(num,multiples) or num
        num=div3(num, multiples) or num
        num=div5(num, multiples) or num
        num=div7(num, multiples) or num
        multiples.append(str(num)) if num!= 1 else None
    else:
        multiples.append(str(1))
    return '*'.join(multiples)
#endregion

#region task2

def num_of_minimal(arr,num):
    if len(arr)>1:
        divider=len(arr)//2
        num=num_of_minimal(arr[divider:],num)
        num=num_of_minimal(arr[:divider],num)
    else:
        if arr[0]<0:
            num+=1
    return num


#endregion

#endregion

compares,copies=0,0

#region lab2
def merge_sort(arr):
    global copies
    global compares
    compares+=1
    if len(arr) > 1:
        m = len(arr) // 2
        left = arr[:m]
        copies+=m
        right = arr[m:]
        copies+=m
        left = merge_sort(left)
        right = merge_sort(right)

        arr = []
        while len(left) > 0 and len(right) > 0:
            compares+=1
            if left[0] < right[0]:
                arr.append(left[0])
                left.pop(0)
            else:
                arr.append(right[0])
                right.pop(0)

        for i in left:
            arr.append(i)
        for i in right:
            arr.append(i)

    return arr

def lab2():
    global copies
    global compares
    tree=os.walk('IncomingDataLab2')
    m=next(tree)
    for el in m[-1]:
        with open('IncomingDataLab2/'+el,'r',encoding='utf-8') as arr_file:
            arr=list(map(int,arr_file.read().split(',')))
            print(el)
            start_time = time.time()
            for i in range(5):
                sorted_arr=merge_sort(arr)
                print(compares,copies) if i ==0 else None
            copies, compares = 0, 0
            print("--- %s seconds ---" % (time.time() - start_time))
            print(sorted_arr)
            print()
#endregion


#region lab checker
def lab(num):
    if num==2:
        lab2()
    elif num==1:
        lab1()
#endregion


if __name__=='__main__':
    lab(1)
    input("Enter smth for lab 2: ")
    lab(2)

